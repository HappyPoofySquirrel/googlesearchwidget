package com.guyverhopkins.searchresults.core

/**
 * created by ghopkins 3/19/2019.
 */
data class SearchResultResponse(var id :Int = 0)