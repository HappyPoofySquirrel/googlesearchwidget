package com.guyverhopkins.searchresults.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagedListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.guyverhopkins.searchresults.R
import com.guyverhopkins.searchresults.core.SearchResultResponse

/**
 * created by ghopkins 3/19/2019.
 */
class SearchReusltsAdapter : PagedListAdapter<SearchResultResponse, SearchReusltsAdapter.SearchResultViewHolder>(SearchResultDiffCallback()){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchResultViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item_search_result, parent, false)
        return SearchResultViewHolder(view)
    }

    override fun onBindViewHolder(holder: SearchResultViewHolder, position: Int) {

    }


    inner class SearchResultViewHolder(private val itemView : View) : RecyclerView.ViewHolder(itemView){

    }
}