package com.guyverhopkins.searchresults.ui

import android.content.Context
import android.widget.LinearLayout

/**
 * created by ghopkins 3/19/2019.
 */
class SearchResults : LinearLayout{

    constructor(context : Context) : super(context)
}